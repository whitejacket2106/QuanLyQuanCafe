﻿Imports Microsoft.Data.SqlClient

Public Class StaffForm
    'Chuỗi kết nối tới SQL Server
    Dim connectionString As String = "Data Source=whitejacketsvpn.duckdns.org,1433;Initial Catalog=NguyenQuocDai_QuanLyQuanCafe;User ID=sa;Password=Nhungnhakhoahoct@i3; TrustServerCertificate=True"

    Private Sub LoadData()
        Try
            Using conn As New SqlConnection(connectionString) 'Mở kết nối đến server
                conn.Open() 'Mở cơ sở dữ liệu
                Dim query As String = "SELECT * FROM Tables" 'Câu lệnh truy xuất dữ liệu
                Dim da As New SqlDataAdapter(query, conn) 'Lấy dữ liệu cho bảng
                Dim dt As New DataTable() 'Tạo data cho bảng
                da.Fill(dt) 'Nhận dữ liệu ra bảng
                DataGridView1.DataSource = dt 'Cho DataGridView1 nhận data

            End Using
        Catch ex As Exception
            MessageBox.Show("Lỗi tải dữ liệu: " & ex.Message)
        End Try
    End Sub

    Private Sub StaffForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter 'Căn giữa header
        DataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter 'Căn giữa nội dung tất cả cell
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill 'Fill đầy bảng

        DataGridView1.ReadOnly = False 'Tắt ReadOnly
        DataGridView1.AllowUserToAddRows = True 'Cho phép thêm dòng mới
        DataGridView1.EditMode = DataGridViewEditMode.EditOnEnter 'Edit On Enter

        LoadData()
    End Sub
    Dim check As Integer = 2

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim f As New Loaisanpham(check)
        f.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim f As New Khachhangdamua(check)
        f.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim f As New Kho(check)
        f.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim f As New Chitietdon(check)
        f.ShowDialog()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim f As New Dangbayban(check)
        f.ShowDialog()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim f As New Nhanvien(check)
        f.ShowDialog()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim f As New Lendon()
        f.Show()
    End Sub
End Class