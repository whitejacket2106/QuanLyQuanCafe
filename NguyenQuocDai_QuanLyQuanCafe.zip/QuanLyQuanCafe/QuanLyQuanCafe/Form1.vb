﻿'Gói thư viện cần thiết
Imports System.Data.SqlClient
Imports System.Threading
Imports Microsoft.Data.SqlClient
Public Class Form1
    ' Chuỗi kết nối tới SQL Server
    Dim connectionString As String = "Data Source=whitejacketsvpn.duckdns.org,1433;Initial Catalog=NguyenQuocDai_QuanLyQuanCafe;User ID=sa;Password=Nhungnhakhoahoct@i3; TrustServerCertificate=True"

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ProgressBar1.Visible = False
        Label4.Visible = False
    End Sub

    'Bấm Đăng nhập
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Lấy tên đăng nhập và pass
        Dim user As String = TextBox2.Text.Trim()
        Dim pass As String = TextBox1.Text.Trim()

        'Kiểm tra 2 hộp thoại
        If user = "" Or pass = "" Then
            MessageBox.Show("Vui lòng nhập đầy đủ Username và Password!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        'Thanh Progress
        ProgressBar1.Value = 0
        ProgressBar1.Visible = True
        Label4.Text = "Đang khởi tạo kết nối..."
        Label4.Visible = True

        ' Giả lập tiến độ khởi tạo (0 → 50%)
        For i As Integer = 0 To 50 Step 10
            ProgressBar1.Value = i
            Label4.Text = "Đang kết nối đến SQL Server... " & i & "%"
            Thread.Sleep(100)
            Application.DoEvents()
        Next

        'Kết nối đến SQL Server để kiểm tra
        Using conn As New SqlConnection(connectionString)
            'Kiểm tra
            Try
                'Mở SQL Server
                conn.Open()
                'Mở bảng account
                Dim sql As String = "SELECT COUNT(*) FROM account WHERE username=@user AND password=@pass"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@user", user) 'Thêm tất cả dữ liệu trùng với user vào biến user
                    cmd.Parameters.AddWithValue("@pass", pass) 'Thêm tất cả dữ liệu trùng với pass vào biến pass

                    'Kiểm tra kết quả
                    Dim result As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    If result > 0 Then
                        'Kiểm tra username trong TextBox
                        If user.ToLower() = "admin" Then
                            Dim f As New AdminForm()
                            f.Show()
                        ElseIf user.ToLower() = "staff" Then
                            Dim f As New StaffForm()
                            f.Show()
                        End If
                        Me.Hide()
                    Else
                        ProgressBar1.Visible = False
                        Label4.Visible = False
                        MessageBox.Show("Sai Username hoặc Password!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            Catch ex As Exception
                MessageBox.Show("Lỗi kết nối SQL Server: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
        ProgressBar1.Visible = False
        Label4.Visible = False
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub
End Class