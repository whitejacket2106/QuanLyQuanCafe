﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Lendon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cboTable = New ComboBox()
        Label1 = New Label()
        cboProduct = New ComboBox()
        Label2 = New Label()
        txtQuantity = New TextBox()
        Label3 = New Label()
        btnAddToOrder = New Button()
        btnSaveOrder = New Button()
        dgvOrderDetails = New DataGridView()
        Label4 = New Label()
        Button1 = New Button()
        CType(dgvOrderDetails, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' cboTable
        ' 
        cboTable.FormattingEnabled = True
        cboTable.Location = New Point(12, 78)
        cboTable.Name = "cboTable"
        cboTable.Size = New Size(121, 23)
        cboTable.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 60)
        Label1.Name = "Label1"
        Label1.Size = New Size(30, 15)
        Label1.TabIndex = 1
        Label1.Text = "Bàn:"
        ' 
        ' cboProduct
        ' 
        cboProduct.FormattingEnabled = True
        cboProduct.Location = New Point(12, 163)
        cboProduct.Name = "cboProduct"
        cboProduct.Size = New Size(121, 23)
        cboProduct.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 145)
        Label2.Name = "Label2"
        Label2.Size = New Size(61, 15)
        Label2.TabIndex = 1
        Label2.Text = "Mặt hàng:"
        ' 
        ' txtQuantity
        ' 
        txtQuantity.Location = New Point(12, 253)
        txtQuantity.Name = "txtQuantity"
        txtQuantity.Size = New Size(121, 23)
        txtQuantity.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 235)
        Label3.Name = "Label3"
        Label3.Size = New Size(54, 15)
        Label3.TabIndex = 1
        Label3.Text = "Số lượng"
        ' 
        ' btnAddToOrder
        ' 
        btnAddToOrder.Location = New Point(490, 364)
        btnAddToOrder.Name = "btnAddToOrder"
        btnAddToOrder.Size = New Size(146, 74)
        btnAddToOrder.TabIndex = 3
        btnAddToOrder.Text = "Add"
        btnAddToOrder.UseVisualStyleBackColor = True
        ' 
        ' btnSaveOrder
        ' 
        btnSaveOrder.Location = New Point(642, 364)
        btnSaveOrder.Name = "btnSaveOrder"
        btnSaveOrder.Size = New Size(146, 74)
        btnSaveOrder.TabIndex = 3
        btnSaveOrder.Text = "Thanh toán"
        btnSaveOrder.UseVisualStyleBackColor = True
        ' 
        ' dgvOrderDetails
        ' 
        dgvOrderDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvOrderDetails.Location = New Point(237, 56)
        dgvOrderDetails.Name = "dgvOrderDetails"
        dgvOrderDetails.Size = New Size(551, 302)
        dgvOrderDetails.TabIndex = 4
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 20F)
        Label4.Location = New Point(411, 16)
        Label4.Name = "Label4"
        Label4.Size = New Size(236, 37)
        Label4.TabIndex = 5
        Label4.Text = "Đơn hàng đã chọn"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(12, 364)
        Button1.Name = "Button1"
        Button1.Size = New Size(146, 74)
        Button1.TabIndex = 6
        Button1.Text = "Đóng"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Lendon
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button1)
        Controls.Add(Label4)
        Controls.Add(dgvOrderDetails)
        Controls.Add(btnSaveOrder)
        Controls.Add(btnAddToOrder)
        Controls.Add(txtQuantity)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(cboProduct)
        Controls.Add(cboTable)
        Name = "Lendon"
        Text = "Lendon"
        CType(dgvOrderDetails, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cboTable As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cboProduct As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnAddToOrder As Button
    Friend WithEvents btnSaveOrder As Button
    Friend WithEvents dgvOrderDetails As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
End Class
