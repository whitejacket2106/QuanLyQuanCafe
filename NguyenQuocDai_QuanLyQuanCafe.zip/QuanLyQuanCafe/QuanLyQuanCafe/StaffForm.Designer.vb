﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StaffForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        Button13 = New Button()
        Label1 = New Label()
        Button8 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        DataGridView1 = New DataGridView()
        Button9 = New Button()
        Button5 = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Variable Display", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(12, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(227, 32)
        Label2.TabIndex = 29
        Label2.Text = "Bàn đang hoạt động"
        ' 
        ' Button13
        ' 
        Button13.Location = New Point(908, 554)
        Button13.Name = "Button13"
        Button13.Size = New Size(144, 68)
        Button13.TabIndex = 28
        Button13.Text = "Đăng xuất"
        Button13.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Yu Gothic UI", 48F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(815, 238)
        Label1.Name = "Label1"
        Label1.Size = New Size(205, 86)
        Label1.TabIndex = 27
        Label1.Text = "STAFF"
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(320, 376)
        Button8.Name = "Button8"
        Button8.Size = New Size(156, 68)
        Button8.TabIndex = 23
        Button8.Text = "Sản phẩm đang bày bán"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(12, 376)
        Button4.Name = "Button4"
        Button4.Size = New Size(151, 68)
        Button4.TabIndex = 20
        Button4.Text = "Chi tiết đơn đã thanh toán"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(633, 302)
        Button3.Name = "Button3"
        Button3.Size = New Size(148, 68)
        Button3.TabIndex = 19
        Button3.Text = "Kho"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(320, 302)
        Button2.Name = "Button2"
        Button2.Size = New Size(156, 68)
        Button2.TabIndex = 18
        Button2.Text = "Khách hàng đã mua"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(12, 302)
        Button1.Name = "Button1"
        Button1.Size = New Size(151, 68)
        Button1.TabIndex = 17
        Button1.Text = "Loại sản phẩm"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 47)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(769, 249)
        DataGridView1.TabIndex = 16
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(633, 376)
        Button9.Name = "Button9"
        Button9.Size = New Size(148, 68)
        Button9.TabIndex = 30
        Button9.Text = "Nhân viên"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(12, 554)
        Button5.Name = "Button5"
        Button5.Size = New Size(151, 68)
        Button5.TabIndex = 31
        Button5.Text = "Lên đơn"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' StaffForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.admin
        BackgroundImageLayout = ImageLayout.Center
        ClientSize = New Size(1064, 634)
        Controls.Add(Button5)
        Controls.Add(Button9)
        Controls.Add(Label2)
        Controls.Add(Button13)
        Controls.Add(Label1)
        Controls.Add(Button8)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(DataGridView1)
        Name = "StaffForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "StaffForm"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Button13 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button9 As Button
    Friend WithEvents Button5 As Button
End Class
