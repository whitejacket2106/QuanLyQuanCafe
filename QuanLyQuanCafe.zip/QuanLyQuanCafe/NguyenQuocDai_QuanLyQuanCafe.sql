-- Adminer 5.3.0 MS SQL  dump
CREATE DATABASE NguyenQuocDai_QuanLyQuanCafe
GO
USE DATABASE NguyenQuocDai_QuanLyQuanCafe
GO

DROP TABLE IF EXISTS [dbo].[Categories];
CREATE TABLE [dbo].[Categories] (
	[CategoryID] int NOT NULL IDENTITY PRIMARY KEY,
	[CategoryName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Categories] ON;
INSERT INTO [dbo].[Categories] ([CategoryID], [CategoryName], [Description]) VALUES
(1,	'Cà phê',	'Các loại cà phê nóng/lạnh'),
(2,	'Trà',	'Trà thảo mộc và trái cây'),
(3,	'Sinh tố',	'Nước ép và sinh tố trái cây'),
(4,	'Bánh ngọt',	'Bánh kem, muffin, cookies'),
(5,	'Nước đóng chai',	'Nước suối và nước ngọt'),
(6,	'Sữa chua',	'Sữa chua uống và sữa chua trộn'),
(7,	'Đồ ăn nhanh',	'Khoai tây chiên, xúc xích'),
(8,	'Sữa lắc',	'Milkshake nhiều hương vị'),
(9,	'Matcha',	'Đồ uống từ bột trà xanh'),
(10,'Special',	'Món đặc biệt theo mùa');
SET IDENTITY_INSERT [dbo].[Categories] OFF;

DROP TABLE IF EXISTS [dbo].[Customers];
CREATE TABLE [dbo].[Customers] (
	[CustomerID] int NOT NULL IDENTITY PRIMARY KEY,
	[CustomerName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Email] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Points] int NULL DEFAULT '((0))'
);

SET IDENTITY_INSERT [dbo].[Customers] ON;
INSERT INTO [dbo].[Customers] ([CustomerID], [CustomerName], [Phone], [Email], [Points]) VALUES
(1,	'Nguyễn Văn A',	'0901111111',	'a@gmail.com',	10),
(2,	'Trần Thị B',	'0902222222',	'b@gmail.com',	20),
(3,	'Lê Văn C',	'0903333333',	'c@gmail.com',	15),
(4,	'Phạm Thị D',	'0904444444',	'd@gmail.com',	5),
(5,	'Hoàng Văn E',	'0905555555',	'e@gmail.com',	12),
(6,	'Bùi Thị F',	'0906666666',	'f@gmail.com',	18),
(7,	'Đỗ Văn G',	'0907777777',	'g@gmail.com',	9),
(8,	'Vũ Thị H',	'0908888888',	'h@gmail.com',	14),
(9,	'Phan Văn I',	'0909999999',	'i@gmail.com',	25),
(10,'Ngô Thị J',	'0910000000',	'j@gmail.com',	8);
SET IDENTITY_INSERT [dbo].[Customers] OFF;

DROP TABLE IF EXISTS [dbo].[Expenses];
CREATE TABLE [dbo].[Expenses] (
	[ExpenseID] int NOT NULL IDENTITY PRIMARY KEY,
	[ExpenseType] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Amount] decimal(12,2) NOT NULL,
	[ExpenseDate] date NULL DEFAULT '(getdate())',
	[Notes] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Expenses] ON;
INSERT INTO [dbo].[Expenses] ([ExpenseID], [ExpenseType], [Amount], [ExpenseDate], [Notes]) VALUES
(1,	'Điện',	1200000,	'Aug  1 2025 12:00:00:AM',	'Tiền điện tháng 7'),
(2,	'Nước',	500000,	'Aug  2 2025 12:00:00:AM',	'Tiền nước tháng 7'),
(3,	'Lương nhân viên',	30000000,	'Aug  5 2025 12:00:00:AM',	'Trả lương tháng 7'),
(4,	'Mua nguyên liệu',	5000000,	'Aug  6 2025 12:00:00:AM',	'Nhập cà phê, trà'),
(5,	'Sửa chữa máy',	2000000,	'Aug 10 2025 12:00:00:AM',	'Sửa máy pha cà phê'),
(6,	'Quảng cáo',	1500000,	'Aug 12 2025 12:00:00:AM',	'Chạy quảng cáo Facebook'),
(7,	'Vệ sinh',	800000,	'Aug 15 2025 12:00:00:AM',	'Dịch vụ vệ sinh quán'),
(8,	'Trang trí',	1000000,	'Aug 18 2025 12:00:00:AM',	'Trang trí theo mùa'),
(9,	'Chi phí POS',	500000,	'Aug 20 2025 12:00:00:AM',	'Phần mềm quản lý bán hàng'),
(10,'Khác',	300000,	'Aug 22 2025 12:00:00:AM',	'Chi phí linh tinh');
SET IDENTITY_INSERT [dbo].[Expenses] OFF;

DROP TABLE IF EXISTS [dbo].[Ingredients];
CREATE TABLE [dbo].[Ingredients] (
	[IngredientID] int NOT NULL IDENTITY PRIMARY KEY,
	[IngredientName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Unit] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Quantity] decimal(10,2) NULL DEFAULT '((0))',
	[ExpirationDate] date NULL,
	[SupplierID] int NULL
);

SET IDENTITY_INSERT [dbo].[Ingredients] ON;
INSERT INTO [dbo].[Ingredients] ([IngredientID], [IngredientName], [Unit], [Quantity], [ExpirationDate], [SupplierID]) VALUES
(1,	'Hạt cà phê Arabica',	'kg',	50,	'Dec 31 2025 12:00:00:AM',	1),
(2,	'Sữa đặc',	'hộp',	100,	'Sep  1 2025 12:00:00:AM',	2),
(3,	'Trà xanh khô',	'kg',	20,	'Oct 15 2025 12:00:00:AM',	3),
(4,	'Bột matcha',	'kg',	15,	'Nov 20 2025 12:00:00:AM',	3),
(5,	'Đường trắng',	'kg',	200,	'Jan  1 2026 12:00:00:AM',	4),
(6,	'Siro đào',	'chai',	30,	'Oct  5 2025 12:00:00:AM',	5),
(7,	'Dâu tươi',	'kg',	25,	'Aug 25 2025 12:00:00:AM',	6),
(8,	'Xoài tươi',	'kg',	40,	'Aug 28 2025 12:00:00:AM',	6),
(9,	'Khoai tây',	'kg',	50,	'Aug 30 2025 12:00:00:AM',	7),
(10,'Bánh muffin',	'cái',	100,	'Sep 10 2025 12:00:00:AM',	8);
SET IDENTITY_INSERT [dbo].[Ingredients] OFF;

DROP TABLE IF EXISTS [dbo].[InventoryTransactions];
CREATE TABLE [dbo].[InventoryTransactions] (
	[TransactionID] int NOT NULL IDENTITY PRIMARY KEY,
	[TransactionType] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[IngredientID] int NOT NULL,
	[Quantity] decimal(10,2) NOT NULL,
	[TransactionDate] datetime NULL DEFAULT '(getdate())',
	[StaffID] int NULL
);

SET IDENTITY_INSERT [dbo].[InventoryTransactions] ON;
INSERT INTO [dbo].[InventoryTransactions] ([TransactionID], [TransactionType], [IngredientID], [Quantity], [TransactionDate], [StaffID]) VALUES
(1,	'Xuất',	1,	5,	'2025-08-20 08:28:50',	2),
(2,	'Xuất',	2,	3,	'2025-08-20 08:28:50',	3),
(3,	'Xuất',	3,	2,	'2025-08-20 08:28:50',	4),
(4,	'Xuất',	4,	1,	'2025-08-20 08:28:50',	5),
(5,	'Xuất',	5,	10,	'2025-08-20 08:28:50',	6),
(6,	'Nhập',	6,	5,	'2025-08-20 08:28:50',	7),
(7,	'Xuất',	7,	3,	'2025-08-20 08:28:50',	8),
(8,	'Xuất',	8,	4,	'2025-08-20 08:28:50',	9),
(9,	'Nhập',	9,	10,	'2025-08-20 08:28:50',	10),
(10,'Xuất',	10,	6,	'2025-08-20 08:28:50',	1);
SET IDENTITY_INSERT [dbo].[InventoryTransactions] OFF;

DROP TABLE IF EXISTS [dbo].[OrderDetails];
CREATE TABLE [dbo].[OrderDetails] (
	[OrderDetailID] int NOT NULL IDENTITY PRIMARY KEY,
	[OrderID] int NOT NULL,
	[ProductID] int NOT NULL,
	[Quantity] int NOT NULL,
	[Price] decimal(10,2) NOT NULL
);

SET IDENTITY_INSERT [dbo].[OrderDetails] ON;
INSERT INTO [dbo].[OrderDetails] ([OrderDetailID], [OrderID], [ProductID], [Quantity], [Price]) VALUES
(1,	1,	1,	2,	25000),
(2,	1,	2,	1,	30000),
(3,	2,	3,	2,	35000),
(4,	2,	4,	1,	20000),
(5,	3,	5,	1,	40000),
(6,	3,	6,	2,	42000),
(7,	4,	7,	1,	45000),
(8,	4,	8,	1,	50000),
(9,	5,	9,	3,	25000),
(10,6,	10,	2,	30000);
SET IDENTITY_INSERT [dbo].[OrderDetails] OFF;

DROP TABLE IF EXISTS [dbo].[Orders];
CREATE TABLE [dbo].[Orders] (
	[OrderID] int NOT NULL IDENTITY PRIMARY KEY,
	[OrderTime] datetime NOT NULL DEFAULT '(getdate())',
	[TableID] int NULL,
	[CustomerID] int NULL,
	[StaffID] int NULL,
	[Status] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Orders] ON;
INSERT INTO [dbo].[Orders] ([OrderID], [OrderTime], [TableID], [CustomerID], [StaffID], [Status]) VALUES
(1,	'2025-08-20 08:28:50',	1,	1,	2,	'Đang pha chế'),
(2,	'2025-08-20 08:28:50',	2,	2,	3,	'Đang phục vụ'),
(3,	'2025-08-20 08:28:50',	3,	3,	4,	'Đã thanh toán'),
(4,	'2025-08-20 08:28:50',	4,	4,	5,	'Đang pha chế'),
(5,	'2025-08-20 08:28:50',	5,	5,	6,	'Đang phục vụ'),
(6,	'2025-08-20 08:28:50',	6,	6,	7,	'Đã thanh toán'),
(7,	'2025-08-20 08:28:50',	7,	7,	8,	'Đang pha chế'),
(8,	'2025-08-20 08:28:50',	8,	8,	9,	'Đang phục vụ'),
(9,	'2025-08-20 08:28:50',	9,	9,	10,	'Đã thanh toán'),
(10,'2025-08-20 08:28:50',	10,	10,	1,	'Đang pha chế');
SET IDENTITY_INSERT [dbo].[Orders] OFF;

DROP TABLE IF EXISTS [dbo].[Payments];
CREATE TABLE [dbo].[Payments] (
	[PaymentID] int NOT NULL IDENTITY PRIMARY KEY,
	[OrderID] int NOT NULL,
	[PaymentMethod] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Amount] decimal(12,2) NOT NULL,
	[PaymentDate] datetime NULL DEFAULT '(getdate())'
);

SET IDENTITY_INSERT [dbo].[Payments] ON;
INSERT INTO [dbo].[Payments] ([PaymentID], [OrderID], [PaymentMethod], [Amount], [PaymentDate]) VALUES
(1,	1,	'Tiền mặt',	80000,	'2025-08-20 08:28:50'),
(2,	2,	'Chuyển khoản',	90000,	'2025-08-20 08:28:50'),
(3,	3,	'Thẻ',	124000,	'2025-08-20 08:28:50'),
(4,	4,	'Tiền mặt',	95000,	'2025-08-20 08:28:50'),
(5,	5,	'Chuyển khoản',	105000,	'2025-08-20 08:28:50'),
(6,	6,	'Thẻ',	60000,	'2025-08-20 08:28:50'),
(7,	7,	'Tiền mặt',	45000,	'2025-08-20 08:28:50'),
(8,	8,	'Chuyển khoản',	75000,	'2025-08-20 08:28:50'),
(9,	9,	'Thẻ',	30000,	'2025-08-20 08:28:50'),
(10,10,	'Tiền mặt',	25000,	'2025-08-20 08:28:50');
SET IDENTITY_INSERT [dbo].[Payments] OFF;

DROP TABLE IF EXISTS [dbo].[Products];
CREATE TABLE [dbo].[Products] (
	[ProductID] int NOT NULL IDENTITY PRIMARY KEY,
	[ProductName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Price] decimal(10,2) NOT NULL,
	[CategoryID] int NOT NULL,
	[Description] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImageUrl] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Products] ON;
INSERT INTO [dbo].[Products] ([ProductID], [ProductName], [Price], [CategoryID], [Description], [ImageUrl]) VALUES
(1,	'Cà phê đen',	25000,	1,	'Cà phê pha phin đậm vị',	NULL),
(2,	'Cà phê sữa',	30000,	1,	'Cà phê phin + sữa đặc',	NULL),
(3,	'Trà đào',	35000,	2,	'Trà + đào miếng',	NULL),
(4,	'Trà chanh',	20000,	2,	'Trà xanh + chanh tươi',	NULL),
(5,	'Sinh tố xoài',	40000,	3,	'Sinh tố từ xoài tươi',	NULL),
(6,	'Sinh tố dâu',	42000,	3,	'Dâu tây xay cùng sữa',	NULL),
(7,	'Matcha latte',	45000,	9,	'Sữa + bột matcha',	NULL),
(8,	'Milkshake socola',	50000,	8,	'Sữa + socola + kem',	NULL),
(9,	'Bánh muffin',	25000,	4,	'Bánh mềm vị socola',	NULL),
(10,'Khoai tây chiên',	30000,	7,	'Khoai tây chiên giòn',	NULL);
SET IDENTITY_INSERT [dbo].[Products] OFF;

DROP TABLE IF EXISTS [dbo].[Staff];
CREATE TABLE [dbo].[Staff] (
	[StaffID] int NOT NULL IDENTITY PRIMARY KEY,
	[StaffName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Position] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Shift] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BaseSalary] decimal(12,2) NULL
);

SET IDENTITY_INSERT [dbo].[Staff] ON;
INSERT INTO [dbo].[Staff] ([StaffID], [StaffName], [Position], [Shift], [BaseSalary]) VALUES
(1,	'Nguyễn Văn NV1',	'Quản lý',	'Sáng',	8000000),
(2,	'Lê Thị NV2',	'Pha chế',	'Sáng',	6000000),
(3,	'Trần Văn NV3',	'Phục vụ',	'Chiều',	5000000),
(4,	'Hoàng Thị NV4',	'Thu ngân',	'Chiều',	5500000),
(5,	'Đỗ Văn NV5',	'Pha chế',	'Tối',	6000000),
(6,	'Phạm Thị NV6',	'Phục vụ',	'Tối',	5000000),
(7,	'Vũ Văn NV7',	'Pha chế',	'Sáng',	6000000),
(8,	'Bùi Thị NV8',	'Thu ngân',	'Tối',	5500000),
(9,	'Nguyễn Văn NV9',	'Phục vụ',	'Sáng',	5000000),
(10,'Trần Thị NV10',	'Pha chế',	'Chiều',	6000000);
SET IDENTITY_INSERT [dbo].[Staff] OFF;

DROP TABLE IF EXISTS [dbo].[Suppliers];
CREATE TABLE [dbo].[Suppliers] (
	[SupplierID] int NOT NULL IDENTITY PRIMARY KEY,
	[SupplierName] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Address] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Phone] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Email] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Suppliers] ON;
INSERT INTO [dbo].[Suppliers] ([SupplierID], [SupplierName], [Address], [Phone], [Email]) VALUES
(1,	'Công ty Cà phê Việt',	'Hà Nội',	'0901234567',	'coffee@viet.vn'),
(2,	'Sữa Ông Thọ',	'Hà Nam',	'0912345678',	'milk@ongtho.vn'),
(3,	'Trà Thái Nguyên',	'Thái Nguyên',	'0923456789',	'tea@thainguyen.vn'),
(4,	'Đường Biên Hòa',	'Đồng Nai',	'0934567890',	'sugar@bienhoa.vn'),
(5,	'Công ty Siro ABC',	'HCM',	'0945678901',	'siro@abc.vn'),
(6,	'Nông trại Dâu Đà Lạt',	'Lâm Đồng',	'0956789012',	'dau@dalat.vn'),
(7,	'Nông trại Xoài',	'Đồng Tháp',	'0967890123',	'xoai@dongthap.vn'),
(8,	'Nhà bánh Sweetie',	'Hà Nội',	'0978901234',	'sweetie@bakery.vn'),
(9,	'Công ty Khoai Tây',	'Lào Cai',	'0989012345',	'khoaitay@vn.vn'),
(10,'Nhà phân phối Matcha',	'HCM',	'0990123456',	'matcha@vn.vn');
SET IDENTITY_INSERT [dbo].[Suppliers] OFF;

DROP TABLE IF EXISTS [dbo].[Tables];
CREATE TABLE [dbo].[Tables] (
	[TableID] int NOT NULL IDENTITY PRIMARY KEY,
	[TableNumber] nvarchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Status] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);

SET IDENTITY_INSERT [dbo].[Tables] ON;
INSERT INTO [dbo].[Tables] ([TableID], [TableNumber], [Status]) VALUES
(1,	'T1',	'Trống'),
(2,	'T2',	'Đang dùng'),
(3,	'T3',	'Trống'),
(4,	'T4',	'Đã đặt trước'),
(5,	'T5',	'Trống'),
(6,	'T6',	'Đang dùng'),
(7,	'T7',	'Trống'),
(8,	'T8',	'Trống'),
(9,	'T9',	'Đang dùng'),
(10,'T10',	'Trống');
SET IDENTITY_INSERT [dbo].[Tables] OFF;

ALTER TABLE [dbo].[Ingredients] ADD
	FOREIGN KEY ([SupplierID]) REFERENCES [Suppliers] ([SupplierID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE [dbo].[InventoryTransactions] ADD
	FOREIGN KEY ([IngredientID]) REFERENCES [Ingredients] ([IngredientID]) ON DELETE NO ACTION ON UPDATE NO ACTION,
	FOREIGN KEY ([StaffID]) REFERENCES [Staff] ([StaffID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE [dbo].[OrderDetails] ADD
	FOREIGN KEY ([OrderID]) REFERENCES [Orders] ([OrderID]) ON DELETE NO ACTION ON UPDATE NO ACTION,
	FOREIGN KEY ([ProductID]) REFERENCES [Products] ([ProductID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE [dbo].[Orders] ADD
	FOREIGN KEY ([CustomerID]) REFERENCES [Customers] ([CustomerID]) ON DELETE NO ACTION ON UPDATE NO ACTION,
	FOREIGN KEY ([StaffID]) REFERENCES [Staff] ([StaffID]) ON DELETE NO ACTION ON UPDATE NO ACTION,
	FOREIGN KEY ([TableID]) REFERENCES [Tables] ([TableID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE [dbo].[Payments] ADD
	FOREIGN KEY ([OrderID]) REFERENCES [Orders] ([OrderID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE [dbo].[Products] ADD
	FOREIGN KEY ([CategoryID]) REFERENCES [Categories] ([CategoryID]) ON DELETE NO ACTION ON UPDATE NO ACTION;