﻿Imports Microsoft.Data.SqlClient

Public Class Khachhangdamua
    Private checkval As Integer

    Public Sub New(check As Integer)
        InitializeComponent()
        checkval = check

    End Sub
    'Chuỗi kết nối
    Dim connectionString As String = "Data Source=whitejacketsvpn.duckdns.org,1433;Initial Catalog=NguyenQuocDai_QuanLyQuanCafe;User ID=sa;Password=Nhungnhakhoahoct@i3; TrustServerCertificate=True"
    Private Sub LoadData()
        Try
            Using conn As New SqlConnection(connectionString) 'Mở kết nối đến server
                conn.Open() 'Mở cơ sở dữ liệu
                Dim query As String = "SELECT * FROM Customers" 'Câu lệnh truy xuất dữ liệu
                Dim da As New SqlDataAdapter(query, conn) 'Lấy dữ liệu cho bảng
                Dim dt As New DataTable() 'Tạo data cho bảng
                da.Fill(dt) 'Nhận dữ liệu ra bảng
                DataGridView1.DataSource = dt 'Cho DataGridView1 nhận data

            End Using
        Catch ex As Exception
            MessageBox.Show("Lỗi tải dữ liệu: " & ex.Message)
        End Try
    End Sub

    Private Sub KhachhangdamuaForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter 'Căn giữa header
        DataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter 'Căn giữa nội dung tất cả cell
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill 'Fill đầy bảng
        If checkval = 1 Then
            DataGridView1.ReadOnly = False 'Tắt ReadOnly
            DataGridView1.AllowUserToAddRows = True 'Cho phép thêm dòng mới
            DataGridView1.EditMode = DataGridViewEditMode.EditOnEnter 'Edit On Enter
        ElseIf checkval = 2 Then
            DataGridView1.ReadOnly = True 'Bật ReadOnly
            DataGridView1.AllowUserToAddRows = False 'Không cho phép thêm dòng mới
        End If
        LoadData()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class