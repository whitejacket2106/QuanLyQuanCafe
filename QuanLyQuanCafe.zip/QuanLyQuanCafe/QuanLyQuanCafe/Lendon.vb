﻿Imports System.Data.SqlClient
Imports Microsoft.Data.SqlClient

Public Class Lendon
    Dim conn As New SqlConnection("Data Source=whitejacketsvpn.duckdns.org,1433;Initial Catalog=NguyenQuocDai_QuanLyQuanCafe;User ID=sa;Password=Nhungnhakhoahoct@i3; TrustServerCertificate=True")

    Private Sub OrderForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadTables()
        LoadProducts()
    End Sub

    ' Load danh sách bàn
    Private Sub LoadTables()
        Dim cmd As New SqlCommand("SELECT TableID, TableNumber FROM Tables WHERE Avalaible = 1", conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        cboTable.DataSource = dt
        cboTable.DisplayMember = "TableNumber"
        cboTable.ValueMember = "TableID"
    End Sub

    ' Load danh sách sản phẩm
    Private Sub LoadProducts()
        Dim cmd As New SqlCommand("SELECT ProductID, ProductName, Price FROM Products", conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        cboProduct.DataSource = dt
        cboProduct.DisplayMember = "ProductName"
        cboProduct.ValueMember = "ProductID"
    End Sub

    ' Thêm sản phẩm vào DataGridView
    Private Sub btnAddToOrder_Click(sender As Object, e As EventArgs) Handles btnAddToOrder.Click
        Dim row As String() = New String() {
            cboProduct.SelectedValue.ToString(),
            cboProduct.Text,
            txtQuantity.Text,
            GetProductPrice(cboProduct.SelectedValue) * Integer.Parse(txtQuantity.Text)
        }
        dgvOrderDetails.Rows.Add(row)
    End Sub

    ' Lấy giá sản phẩm
    Private Function GetProductPrice(productId As Integer) As Decimal
        Dim cmd As New SqlCommand("SELECT Price FROM Products WHERE ProductID = @id", conn)
        cmd.Parameters.AddWithValue("@id", productId)
        conn.Open()
        Dim price As Decimal = Convert.ToDecimal(cmd.ExecuteScalar())
        conn.Close()
        Return price
    End Function

    ' Lưu đơn hàng
    Private Sub btnSaveOrder_Click(sender As Object, e As EventArgs) Handles btnSaveOrder.Click
        conn.Open()
        Dim tran As SqlTransaction = conn.BeginTransaction()

        Try
            ' Tạo Order
            Dim cmdOrder As New SqlCommand("INSERT INTO Orders (OrderTime, TableID, Status) 
                                            OUTPUT INSERTED.OrderID 
                                            VALUES (GETDATE(), @TableID, 'Pending')", conn, tran)
            cmdOrder.Parameters.AddWithValue("@TableID", cboTable.SelectedValue)
            Dim orderId As Integer = Convert.ToInt32(cmdOrder.ExecuteScalar())

            ' Thêm OrderDetails
            For Each row As DataGridViewRow In dgvOrderDetails.Rows
                If Not row.IsNewRow Then
                    Dim cmdDetail As New SqlCommand("INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price) 
                                                     VALUES (@OrderID, @ProductID, @Quantity, @Price)", conn, tran)
                    cmdDetail.Parameters.AddWithValue("@OrderID", orderId)
                    cmdDetail.Parameters.AddWithValue("@ProductID", Convert.ToInt32(row.Cells(0).Value))
                    cmdDetail.Parameters.AddWithValue("@Quantity", Convert.ToInt32(row.Cells(2).Value))
                    cmdDetail.Parameters.AddWithValue("@Price", Convert.ToDecimal(row.Cells(3).Value))
                    cmdDetail.ExecuteNonQuery()
                End If
            Next

            tran.Commit()
            MessageBox.Show("Lưu đơn hàng thành công!")

        Catch ex As Exception
            tran.Rollback()
            MessageBox.Show("Lỗi: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class